Releases
********

1.0.0
=====
* split files into small chunks
* Convert chunks into tarfiles
* join files
