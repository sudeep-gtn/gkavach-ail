#!/usr/bin/env python2

##
# fsplit
# https://github.com/leosartaj/fsplit.git
#
# Copyright (c) 2014 Sartaj Singh
# Licensed under the MIT license.
##

from info import __version__ # define __version__ variable
from info import __desc__ # define __desc__ variable for description
